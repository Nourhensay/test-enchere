package MODEL;

import java.util.ArrayList;
import java.util.List;

public class Membre {
	private int id;
	private String  nom;
	public List<produit>collections =new ArrayList();
	 public List<enchere> encheres=new ArrayList();
	 public List<offre> offres=new ArrayList();
	 
	public Membre(int id, String nom) {
		
		this.id = id;
		this.nom = nom;
	}
	public String description () {
		return "id: "+id  + "###Nom: " + nom;
		
	}
	public  void addEnchere( enchere e) {
		encheres.add(e);
	}
	public  void addOffre( offre o) {
		offres.add(o);
	}
	
	public  void addProduit( produit p) {
		collections.add(p);
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
}

	