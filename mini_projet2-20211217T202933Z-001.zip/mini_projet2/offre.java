package MODEL;

public class offre {
	private Membre me;
	private enchere en;
	private float  prix;
	
	public offre(Membre me, enchere en, float prix) {
	
		this.me = me;
		this.en = en;
		this.prix = prix;
	}	
	public Membre getMe() {
		return me;
	}
	public void setMe(Membre me) {
		this.me = me;
	}
	public enchere getEn() {
		return en;
	}
	public void setEn(enchere en) {
		this.en = en;
	}
	public float getPrix() {
		return prix;
	}
	public void setPrix(float prix) {
		this.prix = prix;
	}
}
