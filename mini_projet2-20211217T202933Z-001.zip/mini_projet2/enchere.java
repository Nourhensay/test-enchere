package MODEL;

import java.util.ArrayList;
import java.util.List;
public class enchere {
	private int id;
	private String desc;
	private float prix;
	private int R;
	private int etat;
	public static List<Membre> ListM=new ArrayList();
	public static int nb=1;
	
	public int getId() {
		return id;
	}
	public enchere(int id, String desc, float prix, int r, int etat) {
		this.id = id;
		this.desc = desc;
		this.prix = prix;
		R = r;
		this.etat = etat;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public float getPrix() {
		return prix;
	}
	public void setPrix(float prix) {
		this.prix = prix;
	}
	public int getR() {
		return R;
	}
	public void setR(int r) {
		R = r;
	}
	public int getEtat() {
		return etat;
	}
	public void setEtat(int etat) {
		this.etat = etat;
	}
	public static List<Membre> getListM() {
		return ListM;
	}
	public static void setListM(List<Membre> listM) {
		ListM = listM;
	}
	public static int getNb() {
		return nb;
	}
	public static void setNb(int nb) {
		enchere.nb = nb;
	}


}
