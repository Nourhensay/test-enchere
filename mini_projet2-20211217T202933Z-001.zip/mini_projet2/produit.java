package MODEL;
import java.io.*;
public class produit {
 private int id ;
 private String nom;
 private String desc ;
 private float prix;
 private enchere e;
 private Membre mb;
 private int etat1;
 public static String[] etat = {"libre","enchere","vendue"};
public produit(int id, String nom, String desc){
	this.id = id;
	this.nom = nom;
	this.desc = desc;
	this.etat1 = 0;
}
public void vendue(offre of) {
	this.mb=of.getMembre();
	this.prix=of.getPrix();
	this.SetEtat1(2);
	}
public String description (){
	if (this.etat1==0) {
		return "id:"+id+"###Nom"+nom+"###desc"+desc+"###Libre";
	}
	if (this.etat1==1) {
		return "id:"+id+"###Nom"+nom+"###desc"+desc+"###enchere : "+e.getId();
		}
	if (this.etat1==2) {
		return "id:"+id+"###Nom"+nom+"###desc"+desc+"###vendue : "+mb.getNom()
				+ "au prix de : "+prix;
	}
	
	
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public String getDesc() {
	return desc;
}
public void setDesc(String desc) {
	this.desc = desc;
}
public float getPrix() {
	return prix;
}
public void setPrix(float prix) {
	this.prix = prix;
}
public enchere getE() {
	return e;
}
public void setE(enchere e) {
	this.e = e;
}
public Membre getMb() {
	return mb;
}
public void setMb(Membre mb) {
	this.mb = mb;
}
public int getEtat1() {
	return etat1;
}
public void setEtat(int etat1) {
	this.etat1 = etat1;
}
public String getEtat() {
	return etat1;
}
public void setEtat(String[] etat1) {
	this.etat1 = etat1;
}


 
 
 
 
