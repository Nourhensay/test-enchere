package Server;

public class LoginTraitement {
	private static String password="admin";
	private static boolean loged ="false";
	public static boolean islogged();
	{
	return logged;
	}
	public static void setlogged(boolean logged)
	{
		LoginTraitement.logged=logged;
		
	}
	publivc static boolean chekPass(String password) 
	{
		return LogginTritement.password.equals(password);
	}

}
