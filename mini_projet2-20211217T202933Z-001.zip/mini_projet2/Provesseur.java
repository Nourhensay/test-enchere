package MODEL;

public class Provesseur {
	private static String password="admin";
	private static boolean Logged=false;
	public static boolean isLogged() {
		   retun Logged
		
	}

}
