package Client;
import java.io*;

import java.net.Socket;

public class ProcessClient {
	public static void main (String [] args) {
		try {
			Socket s =new Socket("127.0.0.1",5000);
			
			ClienSend cs= new ClientSend(s);
			cs.start();
			
			ClientReceive cr= new ClientReceive(s);
			cr.start();
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
